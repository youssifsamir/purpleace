// common devices widths for responsitivity

const mobileWidth = 600;
