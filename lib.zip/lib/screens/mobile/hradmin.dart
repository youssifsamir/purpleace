// packages
import 'package:flutter/widgets.dart';

class HRAdminScreen extends StatelessWidget {
  const HRAdminScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
